<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\JWTController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['middleware' => 'api'], function($router) {
    Route::post('/register', [JWTController::class, 'register']);
    Route::post('/login', [JWTController::class, 'login']);
    Route::post('/logout', [JWTController::class, 'logout']);
    Route::post('/refresh', [JWTController::class, 'refresh']);
    Route::post('/profile', [JWTController::class, 'profile']);
});

Route::get('/availableproducts', 'App\Http\Controllers\productsController@getProducts');
Route::post('/newproduct', 'App\Http\Controllers\productsController@addProduct');
Route::post('/updateproduct/{id}','App\Http\Controllers\productsController@updateProduct');
Route::delete('/deleteproduct/{id}', 'App\Http\Controllers\productsController@deleteProduct');

Route::get('/availablecompanies', 'App\Http\Controllers\adminController@getCompanies');
Route::post('/newcompany', 'App\Http\Controllers\adminController@addCompany');
Route::post('/updatecompany/{id}','App\Http\Controllers\adminController@updateCompany');
Route::delete('/deletecompany/{id}', 'App\Http\Controllers\adminController@deleteCompany');

Route::get('/availablecontacts', 'App\Http\Controllers\adminController@getContacts');
Route::post('/newcontact', 'App\Http\Controllers\adminController@addContact');
Route::post('/updatecontact/{id}','App\Http\Controllers\adminController@updateContact');
Route::delete('/deletecontact/{id}', 'App\Http\Controllers\adminController@deleteContact');

Route::get('/availabletaxes', 'App\Http\Controllers\adminController@getTaxes');
Route::post('/newtax', 'App\Http\Controllers\adminController@addTax');
Route::post('/updatetax/{id}','App\Http\Controllers\adminController@updateTax');
Route::delete('/deletetax/{id}', 'App\Http\Controllers\adminController@deleteTax');

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
